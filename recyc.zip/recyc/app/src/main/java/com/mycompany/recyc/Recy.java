package com.mycompany.recyc;
import android.support.v7.app.*;
import android.os.*;

public class Recy extends AppCompatActivity
    {

        @Override
        protected void onCreate ( Bundle savedInstanceState )
            {
                // TODO: Implement this method
                super.onCreate ( savedInstanceState );
                setContentView(R.layout.recy);
            }
    
}
