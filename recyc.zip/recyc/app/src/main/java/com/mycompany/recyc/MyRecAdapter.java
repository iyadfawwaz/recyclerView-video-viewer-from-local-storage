package com.mycompany.recyc;
import android.support.v7.widget.RecyclerView;
import android.widget.TextView;
import android.widget.VideoView;
import android.widget.LinearLayout;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.view.View;
import android.net.*;
import android.widget.*;
import java.util.*;
import android.support.v7.app.*;
import android.content.*;

public class MyRecAdapter extends RecyclerView.Adapter<MyRecAdapter.ViewHolder>
{
   // private MyListData[] listdata;
    private ArrayList<MyListData> arlist;
    public MyRecAdapter(ArrayList<MyListData> alist){
        //this.listdata= mlistdata;
        this.arlist=alist;
        }
    @Override
    public ViewHolder onCreateViewHolder ( ViewGroup p1, int p2 )
        {
            LayoutInflater linf = LayoutInflater.from(p1.getContext());
            View listitem = linf.inflate(R.layout.list_item,p1,false);
            ViewHolder viewholder = new ViewHolder(listitem);
            return viewholder;
            // TODO: Implement this method
           // return null;
        }

    @Override
    public void onBindViewHolder ( final ViewHolder vh, int position )
        {
            //final MyListData mylistdata= listdata[position];
            final MyListData armylistdata = arlist.get(position);
          //  final MediaController mcon = new MediaController(vh.itemView.getContext());
            vh.videoview.setOnClickListener ( new View.OnClickListener ( ){

                        @Override
                        public void onClick ( View p1 )
                            {
                               // VideoView vidx = (VideoView)
                                AlertDialog adial=new AlertDialog.Builder(vh.itemView.getContext())
                         //   AlertDialog dial =   adial 
                            .setCancelable(true)
                                .setIcon(R.drawable.ic_launcher)
                                .setView(R.layout.dialog_vid)
                                .setTitle(armylistdata.getDisplayname()).create();
                                adial.show();
                              //  View vc = adial.findViewById(R.layout.dialog_vid);
                                VideoView vidx =(VideoView)adial.findViewById(R.id.dialogvidVideoView1);
                                TextView notit= (TextView)adial.findViewById(R.id.dialogvidTextView1);
                                vidx.setVideoURI(armylistdata.getUri());
                                notit.setText(armylistdata.getTitle());
                                final MediaController mc = new MediaController(adial.getContext());
                               // mc.show();
                                vidx.setOnClickListener ( new View.OnClickListener ( ){

                                            @Override
                                            public void onClick ( View p1 )
                                                {
                                                    Intent i = new Intent(vh.itemView.getContext(),Fullscr.class);
                                                    i.putExtra("fullstr",armylistdata.getPath());
                                                    vh.itemView.getContext().startActivity(i);
                                                    //mc.show();
                                                    // TODO: Implement this method
                                                }
                                        } );
                                vidx.setMediaController(mc);
                              //  adial.show();
                                vidx.start();
                                mc.show();
                                // TODO: Implement this method
                            }

                
            });
          //  vh.textview.setText(armylistdata.getPath());
          vh.title.setText(armylistdata.getTitle());
          vh.artist.setText(armylistdata.getArtist());
          vh.displayname.setText(armylistdata.getDisplayname());
          vh.videoview.setVideoURI(armylistdata.getUri());
          vh.videoview.setKeepScreenOn(true);
          vh.videoview.canSeekForward();
          vh.videoview.canSeekBackward();
        //  vh.videoview.start();
            vh.linearlayout.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view){
                  Toast.makeText(  view.getContext(),armylistdata.getPath(),Toast.LENGTH_LONG).show();
                }
            });
            
            // TODO: Implement this method
        }

    @Override
    public int getItemCount ( )
        {
            // TODO: Implement this method
           // return listdata.length;
           return arlist.size();
        }

        

        public static class ViewHolder extends RecyclerView.ViewHolder {
            
          //  public TextView textview;
            public TextView title;
            public TextView artist;
            public TextView displayname;
            public VideoView videoview;
            public LinearLayout linearlayout;
            public MediaController mcont;
            public ViewHolder(View itemView){
                super(itemView);
              //  this.textview = (TextView)itemView.findViewById(R.id.listitemTextView1);
                this.videoview=(VideoView)itemView.findViewById(R.id.listitemVideoView1);
                this.linearlayout=(LinearLayout)itemView.findViewById(R.id.listLinearlay);
                this.artist=(TextView)itemView.findViewById(R.id.artist);
                this.displayname=(TextView)itemView.findViewById(R.id.displayname);
                this.title=(TextView)itemView.findViewById(R.id.title);
                this.mcont = new MediaController(itemView.getContext());
            }
        }
      
    
}
