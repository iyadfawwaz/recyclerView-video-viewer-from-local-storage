package com.mycompany.recyc;
import java.util.*;
import android.content.*;

public class MyArrayList extends ArrayList<String>
{
        public MyArrayList ( )
            {}

        @Override
        public boolean add ( String e )
            {
                // TODO: Implement this method
                return super.add ( e );
            }
    
}
