package com.mycompany.recyc;
import android.net.*;

public class MyListData
{
    private String path;
    private String title;
    private String artist;
    private String displayname;
    private Uri urix;
    @SuppressWarnings("unused")
    private MyListData(){}
    public MyListData(String pathstr,String title,String artist,String displayname){
        this.path=pathstr;
        this.artist=artist;
        this.displayname=displayname;
        this.title=title;
    }
    public String getPath(){
        return path;
    }
    public void setPath(String pastr){
        this.path=pastr;
    }
    public Uri getUri(){
        return Uri.parse(this.path);
    }
    public void setUrix(Uri uriPa){
     this.urix=uriPa;
    }
    public String getTitle()
    {
        return title;
    }
    public String getDisplayname(){
        return displayname;
    }
    public String getArtist(){
        return artist;
    }
}
