# recyclerView-video-viewer-feom-local-storage
ادخال اوتوماتيكي لكل الفيديو داخل ذاكرة الجهاز ووضعها في recyclerView 
