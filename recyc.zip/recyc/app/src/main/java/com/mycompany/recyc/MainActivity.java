package com.mycompany.recyc;

import android.app.*;
import android.os.*;
import android.support.v7.widget.*;
import android.provider.*;
import android.net.*;
import android.database.*;
import android.content.*;
import android.support.v7.app.*;
import java.util.*;
import android.widget.*;
import android.view.*;

public class MainActivity extends AppCompatActivity 
{
    private MyListData[] mydatalist;
    private ArrayList<MyListData> alist;
    private RecyclerView rec;
    private MyRecAdapter mrec;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        hiddenbar();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
       // final MyListData[] mylistdata = new MyListData[]{};
        alist = new ArrayList<MyListData>();
        rec=(RecyclerView)findViewById(R.id.mainandroid_support_v7_widget_RecyclerView);
        mrec= new MyRecAdapter(alist);
        
  
        
        addVid();
    }
    public void addVid(){
      ContentResolver cres=  getContentResolver();
       Uri vidUri= MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        Cursor cursor = cres.query(vidUri,null,null,null,null);
        
        if(vidUri!=null && cursor.moveToFirst()){
            int intData = cursor.getColumnIndex(MediaStore.Video.Media.DATA);
            int intTitle = cursor.getColumnIndex(MediaStore.Video.Media.TITLE);
            int intArtist = cursor.getColumnIndex(MediaStore.Video.Media.ARTIST);
            int intDisplayname = cursor.getColumnIndex(MediaStore.Video.Media.DISPLAY_NAME);
       
            do{
           String path =cursor .getString(intData);
           String title = cursor.getString(intTitle);
           String artist = cursor.getString(intArtist);
           String displayname=cursor.getString(intDisplayname);
      //  mydatalist[cursor.getColumnCount()] = new MyListData(path);
        alist.add(new MyListData(path,title,artist,displayname));
                  //  rec.setAdapter(mrec);
        }while(cursor.moveToNext());
        rec.setLayoutManager(new LinearLayoutManager(this));
        rec.setAdapter(mrec);
    }
    
}
public void rdothis(String pathstr){
    MyListData[] mylist = new MyListData[]{
       // new MyListData()
    };
    
    
}
public void hiddenbar(){
  View decview=  getWindow().getDecorView();
  decview.setFitsSystemWindows(true);
  decview.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);
  
  
    }

@Override
protected void onStart ( )
    {
        hiddenbar();
        // TODO: Implement this method
        super.onStart ( );
    }

@Override
protected void onResume ( )
    {
        hiddenbar();
        // TODO: Implement this method
        super.onResume ( );
    }

@Override
protected void onPause ( )
    {
        hiddenbar();
        // TODO: Implement this method
        super.onPause ( );
    }

@Override
public boolean onTouchEvent ( MotionEvent event )
    {
      hiddenbar();
        // TODO: Implement this method
        return true;
        //super.onTouchEvent ( event );
    }
    
    
    

}
