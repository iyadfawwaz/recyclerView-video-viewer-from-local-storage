package com.mycompany.recyc;
import android.support.v7.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.net.*;

public class Fullscr extends AppCompatActivity
    {
        private VideoView vd;
        private MediaController mcon;

        @Override
        protected void onCreate ( Bundle savedInstanceState )
            {
                hiddenbar();
                // TODO: Implement this method
                super.onCreate ( savedInstanceState );
                setContentView(R.layout.fullscr);
                vd=(VideoView)findViewById(R.id.fullscrVideoView1);
                vd.setVideoURI(Uri.parse(getIntent().getStringExtra("fullstr")));
                mcon=new MediaController(this);
                vd.setMediaController(mcon);
                vd.start();
                mcon.show();
            }
        public void hiddenbar(){
                View decview=  getWindow().getDecorView();
                decview.setFitsSystemWindows(true);
                decview.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);


            }

        @Override
        protected void onStart ( )
            {
                hiddenbar();
                // TODO: Implement this method
                super.onStart ( );
            }

        @Override
        protected void onStop ( )
            {
                hiddenbar();
                // TODO: Implement this method
                super.onStop ( );
            }

        @Override
        protected void onResume ( )
            {
                hiddenbar();
                // TODO: Implement this method
                super.onResume ( );
            }

        @Override
        protected void onRestart ( )
            {
                hiddenbar();
                // TODO: Implement this method
                super.onRestart ( );
            }

        @Override
        public boolean onTouchEvent ( MotionEvent event )
            {
                hiddenbar();
                // TODO: Implement this method
                return true;
                //super.onTouchEvent ( event );
            }
            
    
}
